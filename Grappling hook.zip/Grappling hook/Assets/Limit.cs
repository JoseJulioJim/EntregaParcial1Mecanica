using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Limit : MonoBehaviour
{
    void Update()
    {
        float limitx = Mathf.Clamp(transform.position.x, -10, 10);
        float limity = Mathf.Clamp(transform.position.y, -4, 4);

        transform.position = new Vector3(limitx, limity, 0);
    }
}
